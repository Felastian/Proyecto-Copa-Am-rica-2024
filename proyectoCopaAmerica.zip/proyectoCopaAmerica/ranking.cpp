#include "Ranking.h"
#include "team.h"
//#include "team.h"

Ranking::Ranking(QString seleccion, int puntaje)
    : pais(seleccion), puntaje(puntaje) {}
Ranking::~Ranking(){}

QString Ranking::getPais(){
    return pais;
}

int Ranking::getPuntaje(){
    return puntaje;
}

void Ranking::setPuntaje(int valor){
    puntaje = valor;
}


void Ranking::agregaUser(Ranking equipo){
    equipos.push_back(equipo);
}
