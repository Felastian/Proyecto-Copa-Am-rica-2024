#include <iostream>
#include <vector>
#include <random>
#include <utility>
#include <cmath>
#include <QApplication>
#include "team.h"

Team::Team(QString nombre, double attack, double defense)
    : nombreEquipo(nombre), attackStrength(attack), defenseStrength(defense) {}

double Team::getAttackStrength() const {
        return attackStrength;
    }

double Team::getDefenseStrength() const {
        return defenseStrength;
    }
QString Team::getNombre(){
    return nombreEquipo;
}

PoissonModel::PoissonModel(const Team& teamA, const Team& teamB) {
        lambdaA = (teamA.getAttackStrength() + teamB.getDefenseStrength()) / 2.0;
        lambdaB = (teamB.getAttackStrength() + teamA.getDefenseStrength()) / 2.0;
    }

int PoissonModel::simulateGoals(double lambda) const {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::poisson_distribution<> d(lambda);
        return d(gen);
    }

std::pair<int, int> PoissonModel::simulateMatch() const {
        int goalsA = simulateGoals(lambdaA);
        int goalsB = simulateGoals(lambdaB);
        return std::make_pair(goalsA, goalsB);
}

MatchSimulator::MatchSimulator(const Team& teamA, const Team& teamB, int simulations)
        : model(teamA, teamB), numSimulations(simulations) {}

std::pair<int, int> MatchSimulator::simulate() {
        int totalGoalsA = 0;
        int totalGoalsB = 0;

        for (int i = 0; i < numSimulations; ++i) {
            auto result = model.simulateMatch();
            totalGoalsA += result.first;
            totalGoalsB += result.second;
        }

        double avgGoalsA = static_cast<double>(totalGoalsA) / numSimulations;
        double avgGoalsB = static_cast<double>(totalGoalsB) / numSimulations;

        int predictedGoalsA = std::round(avgGoalsA);
        int predictedGoalsB = std::round(avgGoalsB);



        return std::make_pair(predictedGoalsA, predictedGoalsB);

    }

