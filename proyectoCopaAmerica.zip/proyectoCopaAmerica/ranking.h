#ifndef RANKING_H
#define RANKING_H
#include "team.h"
#include <vector>
#include <QApplication>

using namespace std;

class Ranking {
public:
    Ranking(QString seleccion, int ptje);
    ~Ranking();
    QString getPais();
    int getPuntaje();
    void setPuntaje(int valor);
    void agregaUser(Ranking user);

private:
    QString pais;
    int puntaje;
    vector<Ranking> equipos;

};

#endif // RANKING_H
