#ifndef GRUPOS_H
#define GRUPOS_H

#include <vector>
//#include <fstream>
//#include <iostream>
//#include <sstream>
#include <team.h>
#include <ranking.h>
#include <qDebug>

using namespace std;

class Grupos {
public:
    Grupos();
    ~Grupos();
    void agregaEquipo(Team equipo);
    void agregaEquipo2(Ranking eq);
    void mostrarEquipos();
    void mostrarEquipos2();
    Team buscaEquipo(QString nombre);
    Ranking buscaEq(QString ee);
private:
    vector<Team> equipos;
    vector<Ranking> equ;
};


#endif // GRUPOS_H
