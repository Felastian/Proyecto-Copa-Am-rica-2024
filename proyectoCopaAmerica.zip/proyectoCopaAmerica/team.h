#ifndef TEAM_H
#define TEAM_H
#include <utility>
#include <random>
#include <QApplication>

class Team
{
public:
    Team(QString nombre, double attack, double defense);
    double getAttackStrength() const;
    double getDefenseStrength() const;
    QString getNombre();
private:
    double attackStrength;
    double defenseStrength;
    QString nombreEquipo;
};

class PoissonModel {
public:
    PoissonModel(const Team& teamA, const Team& teamB);
    int simulateGoals(double lambda) const;
    std::pair<int, int> simulateMatch() const;
private:
    double lambdaA;
    double lambdaB;
};


class MatchSimulator {
public:
    MatchSimulator(const Team& teamA, const Team& teamB, int simulations);
    std::pair<int,int> simulate();
    int getPredictedGoalsA() const {return predictedGoalsA;}
    int getPredictedGoalsB() const {return predictedGoalsB;}

private:
    PoissonModel model;
    int numSimulations;
    int predictedGoalsA;
    int predictedGoalsB;
};

#endif // TEAM_H
