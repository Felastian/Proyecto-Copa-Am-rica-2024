#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <Qfile>
#include <QString>
#include <QTextStream>
#include <QDebug>
#include "Grupos.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QStringList textosIngresados;
    Grupos grupos;
    QStringList txtingr;



public slots:
    void mostrarPagina1();
    void mostrarPagina2();
    void mostrarPagina3();
    void mostrarPaginaResultado();
    void simularPartido();
    void verPuntos();
    void on_pushButton_5_clicked();
    void on_saveButton_clicked();
};
#endif // MAINWINDOW_H
