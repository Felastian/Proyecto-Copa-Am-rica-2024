#include "Grupos.h"

Grupos::Grupos() {}

Grupos::~Grupos(){
}

void Grupos::agregaEquipo(Team equipo){
    equipos.push_back(equipo);
}

void Grupos::agregaEquipo2(Ranking equipo){
    equ.push_back(equipo);
}

Ranking Grupos::buscaEq(QString ee){
    for(auto p: equ){
        QString nombre_equipo = p.getPais();
        if(nombre_equipo.compare(ee, Qt::CaseInsensitive) == 0){ // Solución de las mayusculas.
            return p;
        }
    }
}

void Grupos::mostrarEquipos2(){
    for (auto p :equ){

    }
}

void Grupos::mostrarEquipos(){
    for(auto participantes : equipos){

    }
}

Team Grupos::buscaEquipo(QString nombre){
    for(auto participantes: equipos){
        QString nombre_equipo = participantes.getNombre();
        if(nombre_equipo.compare(nombre, Qt::CaseInsensitive) == 0){ // Solución de las mayusculas.
            return participantes;
        }
    }

}





