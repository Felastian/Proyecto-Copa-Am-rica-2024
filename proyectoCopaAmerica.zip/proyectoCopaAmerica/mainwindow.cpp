#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "team.h"
#include "Grupos.h"
#include "ranking.h"
#include <Qfile>
#include <QString>
#include <QTextStream>
#include <QDebug>

Grupos grupos;
Grupos grupos2;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Conectar botones a las funciones de cambio de página
    QObject::connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(mostrarPagina2()));
    QObject::connect(ui->startButton, SIGNAL(clicked()), this, SLOT(simularPartido()));
    QObject::connect(ui->pushButton_3, SIGNAL(clicked()), this, SLOT(mostrarPagina3()));
    QObject::connect(ui->pushButton_4,SIGNAL(clicked()), this, SLOT(mostrarPagina1()));
    QObject::connect(ui->pushButton_2,SIGNAL(clicked()), this, SLOT(mostrarPagina1()));
    QObject::connect(ui->pushButton_5, SIGNAL(clicked()), this, SLOT(verPuntos()));
    QObject::connect(ui->boton_resultados, SIGNAL(clicked()), this, SLOT(mostrarPaginaResultado()));
    QObject::connect(ui->boton_volver,SIGNAL(clicked()), this, SLOT(mostrarPagina1()));


    QObject::connect(ui->saveButton, &QPushButton::clicked, this, &MainWindow::on_saveButton_clicked);
    QObject::connect(ui->pushButton_5, &QPushButton::clicked, this, &MainWindow::on_pushButton_5_clicked);



    // Abrir Archivo //

    QFile file(":/new/prefix1/datos_v1.csv"); // Abrimos archivo

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "No se pudo abrir el archivo:" << ":/new/prefix1/config.csv";
        return;
    }

    QTextStream in(&file); // Manejador del archivo
    QString linea; // Variable que guarda los string
    int indice = 0;

    // Agregamos los objetos

    while(!in.atEnd()){
        linea = in.readLine();
        indice += 1;
        if(indice >= 2){
            QStringList items = linea.split(';');
            QString equipo = items[0];
            double atk = items[1].toDouble();
            double def = items[2].toDouble();

            //qDebug()<< "equipo: " << equipo <<" ataque: "<<atk << " defensa: " << def;
            Team nuevoEquipo(equipo,atk,def);
            grupos.agregaEquipo(nuevoEquipo);
        }
    }
    file.close();


    ///////////RANKING/////////////////////////////////

    QFile file2(":/new/prefix1/datoscopa.csv");

    if (!file2.open(QIODevice::ReadOnly)) {
        qWarning() << "No se pudo abrir el archivo:" << ":/new/prefix1/config.csv";
        return;
    }
    QTextStream in2(&file2); // Manejador del archivo
    QString linea2; // Variable que guarda los string
    int indice2 = 0;

    // Agregamos los objetos al inventario

    while(!in2.atEnd()){
        linea2 = in2.readLine();
        indice2 += 1;
        int ptje=0;
        if(indice2 >= 2){
            QStringList items2 = linea2.split(';');
                QString equipo1 = items2[0];
                int fecha1 = items2[1].toInt();
                int fecha2 = items2[2].toInt();
                int fecha3 = items2[3].toInt();
                int fecha4 = items2[4].toInt();
                int fecha5 = items2[5].toInt();
                int fecha6 = items2[6].toInt();
                ptje = fecha1+fecha2+fecha3+fecha4+fecha5+fecha6;
                //qDebug()<< "equipo: " << ptje;
                Ranking nuevoUsuario(equipo1,ptje);
                grupos2.agregaEquipo2(nuevoUsuario);
        }
    }
    file2.close();


     ///////////RESULTADOS/////////////////////////////////

    QFile file3(":/new/prefix1/datosresultados.csv");

    if (!file3.open(QIODevice::ReadOnly)) {
        qWarning() << "No se pudo abrir el archivo:" << ":/new/prefix1/datosresultados.csv";
        return;
    }
    QTextStream in3(&file3); // Manejador del archivo
    QString linea3; // Variable que guarda los string
    int indice3 = 0;
    QString equipo11;
    QString equipo12;
    QString equipo21;
    QString equipo22;
    QString equipo31;
    QString equipo32;
    QString equipo41;
    QString equipo42;
    QString equipo51;
    QString equipo52;
    QString gol11;
    QString gol12;
    QString gol21;
    QString gol22;
    QString gol31;
    QString gol32;
    QString gol41;
    QString gol42;
    QString gol51;
    QString gol52;


    while(!in3.atEnd()){
        linea3 = in3.readLine();
        indice3 += 1;
        //int ptje=0;
        if(indice3 == 1){
            QStringList items3 = linea3.split(';');
            equipo11 = items3[0];
            equipo12 = items3[2];
            gol11 = items3[1];
            gol12 = items3[3];
            ui->equipo11->setText(equipo11);
            ui->equipo12->setText(equipo12);
            ui->re11->setText(gol11);
            ui->re12->setText(gol12);
        }
        else if(indice3 == 2){
            QStringList items3 = linea3.split(';');
            equipo21 = items3[0];
            equipo22 = items3[2];
            gol21 = items3[1];
            gol22 = items3[3];
            ui->equipo21->setText(equipo21);
            ui->equipo22->setText(equipo22);
            ui->res211->setText(gol21);
            ui->res22->setText(gol22);
        }
        else if(indice3 == 3){
            QStringList items3 = linea3.split(';');
            equipo31 = items3[0];
            equipo32 = items3[2];
            gol31 = items3[1];
            gol32 = items3[3];
            ui->equipo31->setText(equipo31);
            ui->equipo32->setText(equipo32);
            ui->re31->setText(gol31);
            ui->re32->setText(gol32);

        }
        else if(indice3 == 4){
            QStringList items3 = linea3.split(';');
            equipo41 = items3[0];
            equipo42 = items3[2];
            gol41 = items3[1];
            gol42 = items3[3];
            ui->equipo41->setText(equipo41);
            ui->equipo42->setText(equipo42);
            ui->re41->setText(gol41);
            ui->re42->setText(gol42);
        }
        else{
            QStringList items3 = linea3.split(';');
            equipo51 = items3[0];
            equipo52 = items3[2];
            gol51 = items3[1];
            gol52 = items3[3];
            ui->equipo51->setText(equipo51);
            ui->equipo52->setText(equipo52);
            ui->re51->setText(gol51);
            ui->re52->setText(gol52);
        }
    }
    file3.close();


     ///////////RESULTADOS/////////////////////////////////


}

void MainWindow::on_pushButton_5_clicked() {
    QString txt1 = ui->textEdit_3->toPlainText();
    QString txt2 = ui->textEdit_4->toPlainText();
    QString txt3 = ui->textEdit_5->toPlainText();
    QString txt4 = ui->textEdit_6->toPlainText();
    QString txt5 = ui->textEdit_7->toPlainText();
    txtingr.clear();
    txtingr.append(txt1);
    txtingr.append(txt2);
    txtingr.append(txt3);
    txtingr.append(txt4);
    txtingr.append(txt5);

}

void MainWindow::verPuntos(){
        if (txtingr.size() < 5) {
            qWarning() << "No se han ingresado suficientes equipos.";
            return;
        }

        QString nomEquipo1 = txtingr[0].toLower().trimmed();
        QString nomEquipo2 = txtingr[1].toLower().trimmed();
        QString nomEquipo3 = txtingr[2].toLower().trimmed();
        QString nomEquipo4 = txtingr[3].toLower().trimmed();
        QString nomEquipo5 = txtingr[4].toLower().trimmed();

        Ranking equipo1 = grupos2.buscaEq(nomEquipo1);
        Ranking equipo2 = grupos2.buscaEq(nomEquipo2);
        Ranking equipo3 = grupos2.buscaEq(nomEquipo3);
        Ranking equipo4 = grupos2.buscaEq(nomEquipo4);
        Ranking equipo5 = grupos2.buscaEq(nomEquipo5);

        if (equipo1.getPais().isEmpty() || equipo2.getPais().isEmpty() || equipo3.getPais().isEmpty() || equipo4.getPais().isEmpty() || equipo5.getPais().isEmpty()) {
            qWarning() << "Equipos no encontrados";
            return;
        }

        QString equiposStr1 = QString("Ptje: %1").arg(equipo1.getPuntaje());
        QString equiposStr2 = QString("Ptje: %1").arg(equipo2.getPuntaje());
        QString equiposStr3 = QString("Ptje: %1").arg(equipo3.getPuntaje());
        QString equiposStr4 = QString("Ptje: %1").arg(equipo4.getPuntaje());
        QString equiposStr5 = QString("Ptje: %1").arg(equipo5.getPuntaje());

        qDebug() << "puntos1: " << equiposStr1;
        qDebug() << "puntos2: " << equiposStr2;
        qDebug() << "puntos3: " << equiposStr3;
        qDebug() << "puntos4: " << equiposStr4;
        qDebug() << "puntos5: " << equiposStr5;

        ui->labelPuntosUser1->setText(equiposStr1);
        ui->labelPuntosUser2->setText(equiposStr2);
        ui->labelPuntosUser3->setText(equiposStr3);
        ui->labelPuntosUser4->setText(equiposStr4);
        ui->labelPuntosUser5->setText(equiposStr5);
    }



void MainWindow::on_saveButton_clicked(){
    QString texto = ui->textEdit->toPlainText();
    QString texto2 = ui->textEdit_2->toPlainText();
    textosIngresados.clear();
    textosIngresados.append(texto);
    textosIngresados.append(texto2);

}

void MainWindow::simularPartido()
{
    QString nombreEquipo1 = textosIngresados[0];
    QString nombreEquipo2 = textosIngresados[1];

    if(nombreEquipo1 == nombreEquipo2){
        QString error_name = "Los equipos ingresados son iguales";
        ui->resultadoLabel->setText(error_name);
        return;
    }

    Team equipoA = grupos.buscaEquipo(nombreEquipo1);
    Team equipoB = grupos.buscaEquipo(nombreEquipo2);

    if(equipoA.getNombre().isEmpty() || equipoB.getNombre().isEmpty()){
        qWarning() << "Equipos no encontrados";
        return;
    }
    MatchSimulator simulator(equipoA, equipoB, 10);
    auto resultado = simulator.simulate();

    // Obtener el resultado de la simulación
    int predictedGoalsA = resultado.first;
    int predictedGoalsB = resultado.second;

    QString equiposStr = QString("Se enfrentan: %1 v/s %2") .arg(equipoA.getNombre()) .arg(equipoB.getNombre());

    // Formatear el resultado en una cadena de texto
    QString resultadoStr = QString("Resultado del partido: %1 - %2")
                            .arg(predictedGoalsA)
                            .arg(predictedGoalsB);

    // Actualizar el QLabel en la página 2
    ui->resultadoLabel->setText(resultadoStr);
    ui->equiposLabel->setText(equiposStr);
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mostrarPagina1()
{
    ui->stackedWidget->setCurrentIndex(0); // Vuelve a la página 1
}

void MainWindow::mostrarPagina2()
{
    ui->stackedWidget->setCurrentIndex(1); // Cambia a la página 2
}

void MainWindow::mostrarPagina3()
{
    ui->stackedWidget->setCurrentIndex(3); // Cambia a la página 2
}

void MainWindow::mostrarPaginaResultado(){
    ui->stackedWidget->setCurrentIndex(2); // Se ingresa a página de resultados
}



